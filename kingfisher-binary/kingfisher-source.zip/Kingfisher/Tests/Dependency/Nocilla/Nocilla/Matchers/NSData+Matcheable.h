//
//  NSData+Matcheable.h
//  Nocilla
//
//  Created by Luis Solano Bonet on 09/11/14.
//  Copyright (c) 2014 Luis Solano Bonet. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LSMatcheable.h"

@interface NSData (Matcheable) <LSMatcheable>

@end
