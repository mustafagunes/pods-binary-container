#import <Foundation/Foundation.h>
#import "LSMatcheable.h"

@interface NSString (Matcheable) <LSMatcheable>

@end
