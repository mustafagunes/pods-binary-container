#import "LSHTTPClientHook.h"

@interface LSASIHTTPRequestHook : LSHTTPClientHook

@end
