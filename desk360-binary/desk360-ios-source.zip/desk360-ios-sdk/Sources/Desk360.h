//
//  Desk360.h
//  Desk360
//
//  Created by Omar on 5/7/19.
//  Copyright © 2019 Teknasyon. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Desk360.
FOUNDATION_EXPORT double Desk360VersionNumber;

//! Project version string for Desk360.
FOUNDATION_EXPORT const unsigned char Desk360VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Desk360/PublicHeader.h>


