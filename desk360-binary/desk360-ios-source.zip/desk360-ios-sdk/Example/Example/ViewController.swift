//
//  ViewController.swift
//  Example
//
//  Created by Omar on 5/9/19.
//  Copyright © 2019 Teknasyon. All rights reserved.
//

import UIKit
import Desk360

final class ViewController: UIViewController {

	@IBOutlet weak var environmentSwitchButton: UISwitch!
	@IBOutlet weak var languageTypeSwitchButton: UISwitch!
	var jsonObject: [String: Any]?
	var deviceId: String?
    var	environment: Desk360Environment = .sandbox
	var appId: String = ""
	var language: String = ""

	override func viewDidLoad() {
		super.viewDidLoad()

		configureDesk360()
	}

	@IBAction func didTapShowWithJsonData(_ sender: Any) {
		jsonObject = [
			"app": "Demo App",
			"device Id": UIDevice.current.identifierForVendor!.uuidString
		]
		appId = "oFkDNLOatwreoPZp43EWRhDdbGGBbgi8"

		showDesk360()
	}

	@IBAction func environmentSwitchValueChanged(_ sender: Any) {
        environment = environmentSwitchButton.isOn ? .sandbox : .production
	}
	@IBAction func didTapShowWithWrongAppId(_ sender: Any) {
		showDesk360()
	}

	@IBAction func didTapPresentButton(_ sender: UIButton) {
		appId = "oFkDNLOatwreoPZp43EWRhDdbGGBbgi8"
		showDesk360()
	}

	@IBAction func didTapPushButton(_ sender: UIButton) {
//		Desk360.show(on: self, animated: true)
		print(Stores.generateRandomString())
	}

}

// MARK: - Configure
extension ViewController {

	func configureDesk360() {

	}

}

// MARK: - Helpers
extension ViewController {

	func showDesk360() {
        Desk360.start(using: .init(appID: appId))
		jsonObject = nil
		appId = ""
		Desk360.show(on: self, animated: true)
        
        // Or if you would like to provide more info here is a full list of the params
        let props = Desk360Properties(
                appID: "1234",
                deviceID: "34567",
                environment: .production,
                language: "en",
                country: "TR",
                userCredentials: .init(name: "John Doe", email: "john@doe.com"),
                bypassCreateTicketIntro: true,
                jsonInfo: ["a": 500, "b": "c"]
        )

        Desk360.start(using: props)
        
	}

}
