# DivKitBinaryCompatibilityFacade

This framework is intended as high level wrapper around DivKit, that have stable ABI.
It only makes sence if your library uses DivKit and distributes as binary framework.

Main DivKit repository is located [here](https://github.com/divkit/divkit).